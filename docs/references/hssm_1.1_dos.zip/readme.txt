To install HSSM on your computer system place disk 1 in drive A: and type 
the following command:        
        
        A:INSTALL

(The program can be installed from another drive, say B, by replacing "A:"
in the previous command with "B:")




**************************************************************************

Additional Message From Program Distributor,      August 4, 1994
--------------------------------------------      --------------

To reduce the number of distribution diskettes from two to one,
the example data files from the second diskette were copied onto the first 
disk under EXAMPLE subdirectory.  Now, HSSM requires only one disk for each
version (1 disk for DOS and 1 disk for WINDOWS). 

Note that users have to manually copy the example files onto hard disk after
installation of HSSM.
